function loadCursor()
{
    document.getElementById("name").focus();
}
function getdata()
{
 
  var  name=document.getElementById("name").value;
  var company_name=document.getElementById("company").value;
  var  email_id=document.getElementById("emailID").value;
  var contact_no=document.getElementById("contactno").value;
  var address =document.getElementById("add").value;

  if(name=== "")
  {
    alert("please enter name :-");
    document.getElementById("name").focus();
  }
  else if(company_name=== "")
  {
    alert("please enter company name ");
    document.getElementById("company").focus();
  }
  else if(email_id==="")
  {
    alert("please enter email id")
    document.getElementById("emailID").focus();
  }
  else if(contact_no==="")
  {
    alert("please enter contact no");
    document.getElementById("contactno").focus();
  }
  else if(address==="")
  {
    alert("please enter address :-");
    document.getElementById("add").focus();
  }else
  {
  document.getElementById("l1").innerHTML=name;
  document.getElementById("l2").innerHTML=contact_no;
  document.getElementById("l3").innerHTML=email_id;
  document.getElementById("l4").innerHTML=company_name;
  document.getElementById("l5").innerHTML=address;
  }
}
function printData()
{
    var printcontents = document.querySelector('.box2');
    if(printcontents)
    {
        printcontents.style.border='1px solid #000';
        printcontents.style.width="100%";
        document.body.innerHTML = printcontents.outerHTML;
        window.print();
    }
}





